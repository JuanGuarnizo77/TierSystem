# Configuración de Entorno Local (Pruebas)

Este documento resume los cambios y ajustes rápidos realizados para poder ejecutar el proyecto localmente sin problemas de dependencias de sistema (como MySQL) ni conflictos con el entorno virtual de Windows.

## 1. Entorno Virtual de Linux
- Se ignoró la carpeta `venv/` existente en el repositorio, ya que fue generada en un sistema **Windows** (contenía la carpeta `Scripts/`).
- Se creó un entorno completamente nuevo llamado `venv_linux/` compatible con el sistema operativo actual (Linux).

## 2. Ajustes en `requirements.txt`
- Se **eliminó** temporalmente `mysqlclient>=2.2.0` para evitar los errores de compilación por falta de librerías de sistema en Linux (`default-libmysqlclient-dev`).
- Se **agregó** `requests>=2.20.0`. Esta librería no estaba documentada en el `requirements.txt` original, pero el archivo `apps/mercado/views.py` ya la estaba importando (código de los compañeros). Esto causaba que el proyecto fallara al arrancar.

## 3. Base de Datos (`tiersystem/settings.py`)
- Se cambió el motor de la base de datos temporalmente a **SQLite** (`django.db.backends.sqlite3`).
- Se eliminaron las credenciales y el puerto de MySQL, permitiendo que Django construyera automáticamente el archivo `db.sqlite3` sin requerir la instalación de un servidor de bases de datos.

## 4. Inicialización
- Se ejecutaron las migraciones (`python manage.py migrate`) para construir las tablas en SQLite.
- Se corrió el script que venía en el repositorio (`seed_cultivos.py`) para poblar la base de datos con algunos cultivos básicos (Café, Maíz, Frijol, etc.).

> **Nota sobre el código del proyecto:**
> No se modificó **ninguna vista (`views.py`)**, modelo, ni lógica de negocio del proyecto. Todo el código del proyecto es exactamente el que dejaron los compañeros en el repositorio. Los únicos cambios fueron estrictamente de configuración (`settings.py` y dependencias) para poder levantar la aplicación.

## 5. Aislamiento del Entorno (Git)
Para garantizar que estos ajustes locales no afecten al resto del equipo de desarrollo, se aplicaron configuraciones especiales en Git a nivel local:
- Se ignoraron los archivos y carpetas nuevas (`venv_linux/`, `db.sqlite3` y este mismo archivo `.md`) agregándolos a `.git/info/exclude`. Esto funciona igual que un `.gitignore` pero de forma completamente invisible para el repositorio remoto.
- Se le indicó a Git que ignore temporalmente los cambios en los archivos que ya existían y fueron modificados para estas pruebas (`requirements.txt` y `tiersystem/settings.py`) usando el comando `git update-index --skip-worktree`.

Con esto, si se agregan módulos, apps o código nuevo, Git solo rastreará ese código, manteniendo los ajustes del entorno local 100% aislados e invisibles.
